The files that are going to be read should be put outside the source folder. (I used the ../ command in my argument area so I hope you get the idea.
I have explained how my code works in the report more and for the stuff you do not understand check the code as it shows comments in almost each and every step of the code.
I think it helps for you to read the report and look at the code simultaneously for you to get the full picture.
I have added the makefile in the Bin folder
I have added the code in the SRC folder